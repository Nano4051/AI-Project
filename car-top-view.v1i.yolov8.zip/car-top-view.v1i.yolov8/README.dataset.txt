# car-top-view > 2025-11-11 5:15pm
https://universe.roboflow.com/kmj-6izdm/car-top-view-xxfzv

Provided by a Roboflow user
License: CC BY 4.0

